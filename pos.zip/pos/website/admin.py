from django.contrib import admin
from .models import BarCod
# Register your models here.
admin.site.register(BarCod)