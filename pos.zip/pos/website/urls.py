from django.urls import path
app_name = 'barcode'
urlpatterns = [
    # path(''),
]